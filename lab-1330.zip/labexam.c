#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#include "labexam.h"



void sort_string(char* str) {
  // implement me
  return;
}


int filter_to_zero(int* ar, int n, bool(*pred)(int)) {
  // implement me
  return -1;
}


int queue_remove_last(queue_t* q) {
  // implement me
  return -1;
}
